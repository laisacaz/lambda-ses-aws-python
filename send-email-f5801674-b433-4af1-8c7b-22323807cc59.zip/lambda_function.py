
import json
import boto3

def lambda_handler(event, context):
    
    sesClient = boto3.client('ses', region_name='us-east-2')

    to_address = event.get('to_address')
    subject = event.get('subject')
    body = event.get('body')
    sender = event.get('sender')
    
    emailResponse = sesClient.send_email(
        Destination={
            "ToAddresses": [to_address]
        },
        Message={
            "Body": {
                "Text": {
                    "Data": body
                }
            },
            "Subject": {
               "Data": subject
            }
        },
        Source=sender
    )

    return {
        'statusCode': 200,
        'body': json.dumps('E-mail enviado com sucesso!')
    }
